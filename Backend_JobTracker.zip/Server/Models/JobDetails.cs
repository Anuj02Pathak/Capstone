﻿namespace Server.Models
{
    public class JobDetails
    {

    }
}
