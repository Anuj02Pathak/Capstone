import "./App.css";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";
import NotFound from "./pages/NotFound";
import Home from "./pages/Home/Home";
import Application from "./components/Application/Application";
import Login from "./services/Login";
import Register from "./services/Register";
import Footer from "./pages/Footer";
import Jobs from "./Job/Jobs";
import JobDetails from "./Job/JobDetails";
import UserProfile from "./components/Application/UserProfile";
import JobForm from "./Job/JobForm";
import JobList from "./Job/JobList";
import Applicants from "./components/Application/Applicants";
import NavBar from "./pages/NavBar";
function App() {

  return (
    <>
      <Router>


        <NavBar />

        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/" element={<Home />} />
          <Route path="/application/:id" element={<Application />} />
          <Route path="/applications/me" element={<Application />} />
          <Route path="/job/getall" element={<Jobs />} />
          <Route path="/job/:id" element={<JobDetails />} />
          <Route path="/myprofile" element={<UserProfile />} />
          <Route path="/add/jobs" element={<JobForm />} />
          <Route path="/update/jobs" element={<JobList />} />
          <Route path="/applicants" element={<Applicants />} />
          <Route path="*" element={<NotFound />} />{" "}
        </Routes>
      </Router>
    </>
  );
}

export default App;
