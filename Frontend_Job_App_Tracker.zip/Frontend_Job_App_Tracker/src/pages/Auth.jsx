
import { jwtDecode } from "jwt-decode";

const GetUserRole = () => {
    const token = localStorage.getItem("token");
    if (!token) {
        console.log("❌ No token found in localStorage");
        return null;
    }

    try {
        const decoded = jwtDecode(token);
        console.log("🔍 Decoded JWT:", decoded); // ✅ Print full decoded token
        const role = decoded.role || decoded["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"];
        console.log("✅ Extracted Role:", role);
        return role;
    } catch (error) {
        console.error("❌ Error decoding token:", error);
        return null;
    }
};

export default GetUserRole;
