/* eslint-disable no-unused-vars */
import { GetUserRole } from "../services/Auth";
import { Link } from "react-router-dom";
import { GiHamburgerMenu } from "react-icons/gi";
import { FaSignOutAlt } from "react-icons/fa";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const NavBar = () => {
  const [role, setRole] = useState(null);
  const [show, setShow] = useState(false);

  /* Role Based Authorization */

  useEffect(() => {
    setRole(GetUserRole());
  }, []);

  const navigate = useNavigate();

  /* Logout Button */
  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };
  console.log(role);


  return (
    <nav className="navbarShow">
      <div className="container">
        <div className="logo">
          <img src="/JobZee-logos__white.png" alt="logo" />
        </div>
        <ul className="menu">

          <li>
            <Link to={"/"}>HOME</Link>
          </li>
          {/* {role === "jobseeker" && (
            <li>
              <Link to={"/applications/me"} onClick={() => setShow(false)}>
                MY APPLICATIONS
              </Link>
            </li>
          )} */}
          {/*  */}


          <li>
            <Link to={"/myprofile"}> MY PROFILE </Link>
          </li>


          <li>
            <Link to={"/applicants"}> APPLICATIONS </Link>
          </li>


          <li>
            <Link to={"/add/jobs"}> ADD JOBS </Link>
          </li>


          <li>
            <Link to={"/update/jobs"}> UPDATE JOBS </Link>
          </li>


          <li>
            <Link to={"/job/getall"}> ALL JOBS </Link>
          </li>

          <li>
            <Link to={"/login"}> Login </Link>
          </li>

          <li>
            <Link to={"/register"}> Register </Link>
          </li>

          <button

            className="btn  btn-sm fw-bold text-uppercase shadow-sm py-2 px-3 rounded-pill d-flex align-items-center justify-content-center gap-2"
          >
            <FaSignOutAlt />
            LOGOUT
          </button>
        </ul>
        {/* <div className="hamburger">
          <GiHamburgerMenu onClick={() => setShow(!show)} />
        </div> */}
      </div>
    </nav>
  );
};

export default NavBar;
