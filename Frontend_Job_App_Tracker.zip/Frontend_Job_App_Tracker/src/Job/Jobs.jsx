
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const Jobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await axios.get("https://localhost:7279/api/Job");
        setJobs(response.data);
        console.log(jobs);

      } catch (err) {
        setError("Failed to load jobs");
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  if (loading) return <p>Loading jobs...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (

    <div className="container mt-4">
      <h2 className="text-center text-primary mt-4 mb-3 pb-2"> All Companies </h2>
      <div className="row">
        {jobs.map((job, index) => (
          <div key={index} className="col-md-4">
            <div className="card p-3 mb-3 shadow-sm">
              <h5>{job.title}</h5>
              <p>{job.category}</p>
              <p>{job.country}</p>
              <Link to={`/job/${job.id}`} className="btn btn-success w-50">Job Details</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Jobs;
