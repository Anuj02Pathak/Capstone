/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from "react";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";

const JobList = () => {
  const [jobs, setJobs] = useState([]);
  const [editJob, setEditJob] = useState(null);

  const fetchJobs = async () => {
    try {
      const response = await axios.get("https://localhost:7279/api/Jobs");
      setJobs(response.data);
    } catch (error) {
      toast.error("Error fetching jobs");
    }
  };

  useEffect(() => {
    fetchJobs();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`https://localhost:7279/api/Jobs/${id}`);
      toast.success("Job deleted successfully!");
      fetchJobs();
    } catch (error) {
      toast.error("Failed to delete job");
    }
  };

  const handleEdit = (job) => {
    setEditJob(job);
  };

  const handleUpdate = async () => {
    try {
      await axios.put(`https://localhost:7279/api/Jobs/${editJob.id}`, editJob);
      toast.success("Job updated successfully!");
      setEditJob(null);
      fetchJobs();
    } catch (error) {
      toast.error("Failed to update job");
    }
  };

  return (
    <>
      <Toaster position="top-center" autoclose={3000} />
      <div className="container my-4">
        <h2 className="text-center mb-4 text-primary fw-bold">Job Listings</h2>
        <div className="row">
          {jobs.map((job) => (
            <div key={job.id} className="col-md-6 col-lg-4">
              <div className="card job-card shadow-sm mb-4">
                <div className="card-body">
                  <h5 className="card-title fw-bold">{job.title}</h5>
                  <p className="card-text text-muted mb-2">{job.category}</p>
                  <p className="card-text">
                    <i className="bi bi-geo-alt-fill text-danger"></i> {job.country}
                  </p>
                  <div className="d-flex justify-content-between">
                    <button className="btn btn-warning btn-sm" onClick={() => handleEdit(job)}>
                      Edit
                    </button>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(job.id)}>
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Edit Job Form */}
        {editJob && (
          <div className="edit-form card p-4 mt-4 shadow-lg">
            <h3 className="text-center text-success fw-bold">Edit Job</h3>
            <input
              type="text"
              className="form-control mb-2"
              value={editJob.title}
              onChange={(e) => setEditJob({ ...editJob, title: e.target.value })}
              placeholder="Job Title"
            />
            <input
              type="text"
              className="form-control mb-2"
              value={editJob.category}
              onChange={(e) => setEditJob({ ...editJob, category: e.target.value })}
              placeholder="Category"
            />
            <input
              type="text"
              className="form-control mb-2"
              value={editJob.country}
              onChange={(e) => setEditJob({ ...editJob, country: e.target.value })}
              placeholder="Country"
            />
            <button className="btn btn-success w-100" onClick={handleUpdate}>
              Update Job
            </button>
          </div>
        )}

        {/* Custom Styles */}
        <style>{`
        .job-card {
          border-radius: 12px;
          transition: transform 0.3s ease-in-out;
        }
        .job-card:hover {
          transform: scale(1.03);
          box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.15);
        }
        .edit-form {
          max-width: 400px;
          margin: auto;
          border-radius: 12px;
          background: #fff;
        }
      `}</style>
      </div>
    </>
  );
};

export default JobList;
