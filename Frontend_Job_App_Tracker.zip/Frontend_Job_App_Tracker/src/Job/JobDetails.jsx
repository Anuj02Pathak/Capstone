import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import axios from "axios";

const JobDetails = () => {
  const { id } = useParams();
  console.log(id);

  const [job, setJob] = useState(null);
  const navigate = useNavigate();
  //, { withCredentials: true }

  useEffect(() => {
    axios
      .get(`https://localhost:7279/api/Job/${id}`)
      .then((res) => {
        setJob(res.data); // Assuming API returns job details directly
      })
      .catch(() => {
        navigate("/notfound");
      });
  }, [id, navigate]);

  if (!job) {
    return <p className="text-center mt-4">Loading job details...</p>;
  }

  return (
    <section className="jobDetail page bg-dark">
      <div className="container">
        <h3 className="text-center mb-4">Job Details</h3>
        <div className="banner p-4 shadow-sm bg-light rounded">
          <p>
            <strong>Title:</strong> <span>{job.title || "N/A"}</span>
          </p>
          <p>
            <strong>Category:</strong> <span>{job.category || "N/A"}</span>
          </p>
          <p>
            <strong>Country:</strong> <span>{job.country || "N/A"}</span>
          </p>
          <p>
            <strong>City:</strong> <span>{job.city || "N/A"}</span>
          </p>
          <p>
            <strong>Location:</strong> <span>{job.location || "N/A"}</span>
          </p>
          <p>
            <strong>Description:</strong>{" "}
            <span>{job.description || "N/A"}</span>
          </p>
          <p>
            <strong>Job Posted On:</strong>{" "}
            <span>{job.jobPostedOn || "N/A"}</span>
          </p>
          <p>
            <strong>Salary:</strong>
            {job.fixedSalary ? (
              <span> {job.fixedSalary} </span>
            ) : (
              <span>
                {" "}
                {job.salaryFrom || "N/A"} - {job.salaryTo || "N/A"}{" "}
              </span>
            )}
          </p>

          <Link
            to={`/application/${job.id}`}
            state={{ companyName: job.title }}
            className="btn btn-success mt-3"
          >
            Apply Now
          </Link>
        </div>
      </div>
    </section>
  );
};

export default JobDetails;
