import axios from "axios";

const API_URL = "https://localhost:7279/api/Notification"; // Backend API

// Fetch all notifications
export const getNotifications = async () => {
    const response = await axios.get(API_URL);
    return response.data;
};

// 🔹 Send Notification (Interviewer Action)
export const sendNotification = async (message, userId) => {
    try {
        await axios.post(API_URL, { message, userId });
        console.log("Notification sent!");
    } catch (error) {
        console.error("Error sending notification:", error);
    }
};