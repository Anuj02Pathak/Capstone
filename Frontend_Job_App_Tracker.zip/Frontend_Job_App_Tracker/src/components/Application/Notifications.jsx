import { useEffect, useState } from "react";
import { getNotifications } from "../../services/notificationService";

const NotificationsPage = () => {
    const [notifications, setNotifications] = useState([]);

    useEffect(() => {
        fetchNotifications();
    }, []);

    const fetchNotifications = async () => {
        const data = await getNotifications();
        setNotifications(data);
    };

    return (
        <div className="container mt-4">
            <h2 className="text-center">All Notifications</h2>
            <ul className="list-group">
                {notifications.length === 0 ? (
                    <p className="text-muted">No notifications found.</p>
                ) : (
                    notifications.map((notif) => (
                        <li key={notif.id} className="list-group-item">
                            {notif.message} <br />
                            <small className="text-muted">{new Date(notif.createdAt).toLocaleString()}</small>
                        </li>
                    ))
                )}
            </ul>
        </div>
    );
};

export default NotificationsPage;
