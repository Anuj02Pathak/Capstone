
import axios from "axios";
import { useState, useEffect } from "react";
import toast, { Toaster } from "react-hot-toast";
import "bootstrap/dist/css/bootstrap.min.css";

const UserProfile = () => {
  const [userData, setUserData] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [editUserId, setEditUserId] = useState(null);
  const [formData, setFormData] = useState({ name: "", email: "", phone: "" });

  // Replace with actual logged-in user ID
  const userId = "jobseeker123";

  useEffect(() => {
    fetchUserData();
    fetchNotifications();

    // Polling for new notifications every 10 seconds
    const interval = setInterval(fetchNotifications, 60000);
    return () => clearInterval(interval);
  }, []);

  // Fetch User Data (Applications)
  const fetchUserData = () => {
    axios
      .get("https://localhost:7279/api/Application")
      .then((response) => {
        setUserData(response.data);
      })
      .catch((error) => console.error("Error fetching data:", error));
  };

  // Fetch Notifications
  const fetchNotifications = () => {
    const token = localStorage.getItem("token"); // Get token for authentication

    axios
      .get("https://localhost:7279/api/Notification/my-notifications", {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setNotifications(response.data);
        response.data.forEach((notif) => {
          toast(`📢 ${notif.message}`, { duration: 5000 });
        });
      })
      .catch((error) => console.error("Error fetching notifications:", error));
  };

  // Open update form
  const openUpdateForm = (user) => {
    setEditUserId(user.id);
    setFormData({ name: user.name, email: user.email, phone: user.phone });
  };

  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  // Handle update
  const handleUpdate = async (e) => {
    e.preventDefault();
    if (!editUserId) return;

    const existingUser = userData.find((user) => user.id === editUserId);
    if (!existingUser) return toast.error("User not found!");

    const updatedData = { ...formData, companyName: existingUser.companyName };

    try {
      await axios.put(
        `https://localhost:7279/api/Application/${editUserId}`,
        updatedData,
        { headers: { "Content-Type": "application/json" } }
      );
      toast.success("Details Updated Successfully!");
      setUserData((prevData) =>
        prevData.map((user) =>
          user.id === editUserId ? { ...user, ...updatedData } : user
        )
      );
      setEditUserId(null);
    } catch (error) {
      toast.error("Update failed!");
      console.error("Error updating details:", error);
    }
  };

  // Handle delete application
  const handleWithdraw = (id) => {
    if (window.confirm("Are you sure you want to withdraw this application?")) {
      axios
        .delete(`https://localhost:7279/api/Application/${id}`)
        .then(() => {
          toast.success("Application Withdrawn!");
          setUserData((prevData) => prevData.filter((user) => user.id !== id));
        })
        .catch((error) => console.error("Error deleting application:", error));
    }
  };

  return (
    <>
      <Toaster position="top-center" />
      <nav className="navbar navbar-light bg-light px-4">
        <h3>Job Tracker</h3>
        <div className="dropdown">
          <button
            className="btn btn-light dropdown-toggle"
            type="button"
            id="notificationsDropdown"
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            🔔 Notifications ({notifications.length})
          </button>
          <ul className="dropdown-menu" aria-labelledby="notificationsDropdown">
            {notifications.length > 0 ? (
              notifications.map((notif, index) => (
                <li key={index} className="dropdown-item">{notif.message}</li>
              ))
            ) : (
              <li className="dropdown-item text-muted">No notifications</li>
            )}
          </ul>
        </div>
      </nav>

      <div className="container mt-4">
        <h2 className="text-center fw-bold">Applied Companies</h2>
        <div className="row">
          {userData.map((user) => (
            <div className="col-md-4" key={user.id}>
              <div className="card p-3 mb-3 shadow-sm">
                {editUserId === user.id ? (
                  <form onSubmit={handleUpdate}>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="form-control mb-2"
                      required
                    />
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="form-control mb-2"
                      required
                    />
                    <input
                      type="text"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="form-control mb-2"
                      required
                    />
                    <button type="submit" className="btn btn-success w-50">
                      Save
                    </button>
                    <button
                      type="button"
                      className="btn btn-secondary w-50"
                      onClick={() => setEditUserId(null)}
                    >
                      Cancel
                    </button>
                  </form>
                ) : (
                  <>
                    <h5>{user.companyName}</h5>
                    <p><strong>Name:</strong> {user.name}</p>
                    <p><strong>Email:</strong> {user.email}</p>
                    <p><strong>Phone:</strong> {user.phone}</p>
                    <button
                      className="btn btn-primary mb-2 w-50"
                      onClick={() => openUpdateForm(user)}
                    >
                      Update
                    </button>
                    <button
                      className="btn btn-danger w-50"
                      onClick={() => handleWithdraw(user.id)}
                    >
                      Withdraw
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default UserProfile;
