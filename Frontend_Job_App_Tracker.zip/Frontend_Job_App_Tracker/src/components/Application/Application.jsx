
import { useState } from "react";
import { Form, Button, Container, Row, Col } from "react-bootstrap";
import { useParams, useLocation, useNavigate, Link } from "react-router-dom";
import axios from "axios";
import {
  FaPaperPlane,
  FaUser,
  FaEnvelope,
  FaPhone,
  FaMapMarker,
  FaFileUpload,
} from "react-icons/fa";
import toast, { Toaster } from "react-hot-toast";

const Application = () => {
  const [address, setAddress] = useState("");
  const [coverLetter, setCoverLetter] = useState("");
  const [resume, setResume] = useState(null);

  const { id } = useParams();

  const location = useLocation();

  const companyName = location.state?.companyName || "Unknown company";

  const navigate = useNavigate();

  // const handleFileChange = (e) => {
  //   setResume(e.target.files[0]);
  // };

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    companyName: companyName,
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // if(formData)
    // {
    //   toast.error("Fill Details")
    //   return;
    // }
    console.log("Form Data:", formData);

    try {
      await axios.post(
        "https://localhost:7279/api/Application/submit",
        JSON.stringify(formData), // Convert to JSON
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );

      toast.success("Application submitted successfully!");
      navigate(`/myprofile`);
    } catch (error) {
      console.error("Error submitting application:", error);
    }
  };


  return (
    <>
      <Toaster position="top-center" autoclose={2000} />
      <section className="application py-5 bg-dark">
        <Container>
          <Row className="justify-content-center">
            <Col md={8} lg={6}>
              <div className="p-4 p-lg-5 shadow-lg rounded bg-white">
                <h3 className="text-center mb-4 text-primary fw-bold">
                  <FaPaperPlane className="me-2" />
                  Application Form
                </h3>
                <p className="text-center text-muted mb-4">
                  Fill out the form below to submit your application.
                </p>

                <Form
                  onSubmit={handleSubmit}
                  className="needs-validation"
                  noValidate
                >
                  {/* Name Field */}
                  <Form.Group className="mb-3">
                    <Form.Label className="form-label fw-bold">
                      <FaUser className="me-2" />
                      Your Name
                    </Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Enter your name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="form-control-lg"
                    />
                  </Form.Group>

                  {/* Email Field */}
                  <Form.Group className="mb-3">
                    <Form.Label className="form-label fw-bold">
                      <FaEnvelope className="me-2" />
                      Your Email
                    </Form.Label>
                    <Form.Control
                      type="email"
                      name="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="form-control-lg"
                    />
                  </Form.Group>

                  {/* Phone Field */}
                  <Form.Group className="mb-3">
                    <Form.Label className="form-label fw-bold">
                      <FaPhone className="me-2" />
                      Your Phone Number
                    </Form.Label>
                    <Form.Control
                      type="number"
                      name="phone"
                      placeholder="Enter your phone number"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="form-control-lg"
                    />
                  </Form.Group>

                  {/* Address Field */}
                  <Form.Group className="mb-3">
                    <Form.Label className="form-label fw-bold">
                      <FaMapMarker className="me-2" />
                      Your Address
                    </Form.Label>
                    <Form.Control
                      type="text"
                      name="address"
                      placeholder="Enter your address"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      required
                      className="form-control-lg"
                    />
                  </Form.Group>

                  {/* Cover Letter Field */}
                  <Form.Group className="mb-3">
                    <Form.Label className="form-label fw-bold">
                      <FaFileUpload className="me-2" />
                      Cover Letter
                    </Form.Label>
                    <Form.Control
                      as="textarea"
                      rows={5}
                      placeholder="Write your cover letter..."
                      value={coverLetter}
                      onChange={(e) => setCoverLetter(e.target.value)}
                      required
                      className="form-control-lg"
                    />
                  </Form.Group>

                  {/* Resume Upload Field */}
                  <Form.Group className="mb-4">
                    <Form.Label className="form-label fw-bold">
                      <FaFileUpload className="me-2" />
                      Upload Resume
                    </Form.Label>
                    <Form.Control
                      type="file"
                      accept=".pdf, .jpg, .png"
                      required
                      className="form-control-lg"
                    />
                  </Form.Group>

                  {/* Submit Button */}
                  <Button
                    variant="primary"
                    type="submit"
                    className="w-100 btn-lg d-flex align-items-center justify-content-center gap-2 fw-bold"
                  >
                    <FaPaperPlane />
                    Send Application
                  </Button>
                </Form>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Application;
