/* eslint-disable no-unused-vars */
// import axios from "axios";
// import { useState, useEffect } from "react";
// import toast, { Toaster } from "react-hot-toast";

// const Applicants = () => {
//   const [jobseekers, setJobseekers] = useState([]);

//   useEffect(() => {
//     axios
//       .get("https://localhost:7279/api/Application") // Fetch Jobseekers
//       .then((response) => {
//         console.log("Fetched Jobseekers:", response.data);
//         setJobseekers(response.data);
//       })
//       .catch((error) => {
//         console.error("Error fetching data:", error);
//       });
//   }, []);

//   // Send Interview Notification
//   const handleSendNotification = (id) => {
//     axios
//       .post(`https://localhost:7279/api/Application/SendNotification/${id}`)
//       .then(() => {
//         toast.success("Interview Notification Sent!");
//       })
//       .catch((error) => {
//         console.error("Error sending notification:", error);
//         toast.error("Failed to send notification.");
//       });
//   };

//   return (
//     <>
//       <Toaster position="top-center" />
//       <div className="container mt-5">
//         <h2 className="text-center fw-bold">Jobseekers</h2>
//         <div className="row">
//           {jobseekers.map((seeker) => (
//             <div className="col-md-4" key={seeker.id}>
//               <div className="card p-3 mb-3 shadow-lg border-0">
//                 <h5 className="fw-bold">{seeker.companyName}</h5>
//                 <p><strong>Name:</strong> {seeker.name}</p>
//                 <p><strong>Email:</strong> {seeker.email}</p>
//                 <p><strong>Phone:</strong> {seeker.phone}</p>
//                 <button
//                   className="btn btn-success w-100"
//                   onClick={() => handleSendNotification(seeker.id)}
//                 >
//                   📩 Send Interview Notification
//                 </button>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>
//     </>
//   );
// };

// export default Applicants;
import axios from "axios";
import { useState, useEffect } from "react";
import toast, { Toaster } from "react-hot-toast";
import { jwtDecode } from "jwt-decode";

const Applicants = () => {
  const [jobseekers, setJobseekers] = useState([]);
  const [employerId, setEmployerId] = useState(null);
  const [message, setMessage] = useState("");

  const handleInputChange = (e) => {
    setMessage(e.target.value); // Update message state
  };


  useEffect(() => {
    // Get the token from localStorage
    const token = localStorage.getItem("token");
    if (token) {
      const decodedToken = jwtDecode(token);
      setEmployerId(decodedToken.userId); // Extract employer's ID
    }

    // Fetch Jobseekers
    axios
      .get("https://localhost:7279/api/Application")
      .then((response) => {
        setJobseekers(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const getEmployerId = () => {
    const token = localStorage.getItem("token");
    if (!token) {
      console.log("⚠️ No token found in local storage");
      return null;
    }

    try {
      const decodedToken = jwtDecode(token);
      console.log("🔍 Decoded JWT Token:", decodedToken);

      // 🔹 Extract employer ID correctly
      const employerId =
        decodedToken[
        "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"
        ];

      console.log("✅ Extracted Employer ID:", employerId);

      return employerId || null;
    } catch (error) {
      console.error("❌ Error decoding JWT token:", error);
      return null;
    }
  };

  const handleSendNotification = (seekerId, message) => {
    const token = localStorage.getItem("token");
    const employerId = getEmployerId(); // ✅ Extract employerId safely

    if (!employerId) {
      toast.error("Failed to get employer ID from token!");
      return;
    }

    const notificationData = {
      userId: String(seekerId), // The job seeker receiving the notification
      employerId: employerId, // The employer sending it
      message: message,
      createdAt: new Date().toISOString(),
    };

    console.log("📢 Sending Notification Data:", notificationData); // Debugging Log

    axios
      .post("https://localhost:7279/api/Notification", notificationData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      })
      .then((response) => {
        console.log("✅ Notification sent:", response.data);
        toast.success("📢 Notification Sent!");
      })
      .catch((error) => {
        console.error(
          "❌ Error sending notification:",
          error.response?.data || error.message
        );
        toast.error("Failed to send notification.");
      });
  };

  return (
    <>
      <Toaster position="top-center" />
      <div className="container mt-5">
        <h2 className="text-center fw-bold">Jobseekers</h2>
        <div className="row">
          {jobseekers.map((seeker) => (
            <div className="col-md-4" key={seeker.id}>
              <div className="card p-3 mb-3 shadow-lg border-0">
                <h5 className="fw-bold">{seeker.companyName}</h5>
                <p>
                  <strong>Name:</strong> {seeker.name}
                </p>
                <p>
                  <strong>Email:</strong> {seeker.email}
                </p>
                <p>
                  <strong>Phone:</strong> {seeker.phone}
                </p>
                {/* <button
                  className="btn btn-success w-100"
                  onClick={() => handleSendNotification(seeker.id, "Your Interview is scheduled for tommorrow")}
                >
                  📩 Send Interview Notification
                </button> */}
                <input
                  type="text"
                  value={message}
                  onChange={handleInputChange}
                  placeholder="Enter notification message"
                />

                <button
                  onClick={() => handleSendNotification(seeker.id, message)}
                >
                  Send Notification
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Applicants;
