/* eslint-disable no-unused-vars */
import { useState } from "react";
import { sendNotification } from "../../services/notificationService";

const SendNotification = () => {
  const [userId, setUserId] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState("");

  const handleSendNotification = async () => {
    if (!userId || !message) {
      setStatus("Please fill all fields.");
      return;
    }

    try {
      await sendNotification(message, userId);
      setStatus("✅ Notification sent successfully!");
      setMessage(""); // Clear input field
    } catch (error) {
      setStatus("❌ Failed to send notification.");
    }
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center">📢 Send Notification</h2>

      {status && <p className="alert alert-info">{status}</p>}

      <div className="form-group">
        <label>Enter User ID:</label>
        <input
          type="text"
          className="form-control"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          placeholder="Enter recipient User ID"
        />
      </div>

      <div className="form-group">
        <label>Notification Message:</label>
        <textarea
          className="form-control"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Enter your message"
        />
      </div>

      <button className="btn btn-primary mt-2" onClick={handleSendNotification}>
        Send Notification
      </button>
    </div>
  );
};

export default SendNotification;
